Open this project in Android Studio and build APK.
App name: Chitragupta
Type: WebView Google Search